#ifndef INTLIST_H
#define INTLIST_H

class IntList
{
	private:
		struct ListNode
		{
			int value;
			ListNode *next;
		};
		ListNode *head;
		
	public:
		IntList(){
			head= nullptr;//set the head as nullptr
		}
		~IntList();
		
		
		void appendNode(int);
		void insertNode(int);
		void deleteNode(int);
		void displayNode();
		void insertSpecific(int, int);
};

#endif
