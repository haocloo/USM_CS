#include <iostream>
using namespace std;

template <class T>
void arrange (T &a, T &b, T &c){
	T small,medium,big;
	
	if((a<b) && (b<c))
		return;
		
	if((a<c) && (c<b)){
		small = a;
		medium = c;
		big = b;
	}
	else if((b<c) && (c<a))
	{
		
	}
	else if((b<a) && (a<c))
	{
		
	}
	else if((c<b) && (b<a))
	{
		
	}
	else
	{
		//(c<a) && (a<b)
	}
	
	a = small;
	b = medium;
	c= big;
	
	return;
}

int main(){
	// test with anyone: int , float, double, char
	return 0;
}

//Question 6: 
//List <double> obj1
// List <int> obj2
