#include <iostream>
#include "IntList.h"
using namespace std;

void IntList::appendNode(int num)
{
	ListNode *newNode, *nodePtr = nullptr;
	
	newNode = new ListNode;
	newNode->value = num;
	newNode->next = nullptr;
	
	if(!head)
		head = newNode;
	else
	{
		nodePtr = head;
		
		//Find the last enode in the list
		while (nodePtr ->next)
			nodePtr = nodePtr ->next;
			
		nodePtr ->next = newNode
	}
}

void IntList::displayList()
{
	ListNode *nodePtr = nullptr;
	nodePtr = head;
	
	while(nodePtr)
	{
		cout<< nodePtr-> value<< endl;
		nodePtr = nodePtr-> next;
	}
}

// 3 6 9 12, insert 10
//in between 9 and 12
void IntList::insertNode(int num)
{
	ListNode *newNode, *nodePtr, *previousNode;
	
	newNode = new ListNode;
	newNode->value = num;
	
	if(!head)
	{
		head = newNode;
		newNode->next= nullPtr;
	}
	else
	{
		nodePtr = head;
		previousNode= nullPtr;
		
		while(nodePtr != nullptr && nodePtr-> value < num)
		{
			previousNode= nodePtr;
			nodePtr = nodePtr->next;
		}
		
		//Node to be inserted first at the list
		if (previousNode == nullptr)
		{
			head = newNode;
			newNode->next = nodePtr;
		}
		else
		{
			previousNode->next = newNode;
			newNode->next = nodePtr;
		}
	}
}

void IntList::deleteNode(int num)
{
	ListNode *nodePtr, *previousNode = nullptr;
	
	if(!head)
		return;
	
	//First node equals to num
	if(head->value == num)
	{
		nodePtr = head->next;
		delete head;
		head = nodePtr;
	}
	else
	{
		nodePtr = head;
		while (nodePtr != nullptr && nodePtr->value != num)
		{
			previousNode = nodePtr;
			nodePtr = nodePtr->next;
		}
		
		//Found node with the value = num
		if (nodePtr){
			previousNode->next = nodePtr->next;
			delete nodePtr;
		}
	}
}

IntList::~IntList()
{
	ListNode *nodePtr, *nextNode;
	
	nodePtr = head;
	while(nodePtr != nullptr)
	{
		nextNode = nodePtr->next;
		delete nodePtr;
		nodePtr = nextNode;
	}
}
int main()
{
	
}
