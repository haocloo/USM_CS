#include <iostream>
#include "IntList.h"
using namespace std;

int main()
{
	IntList list;
	
	list.appendNode(2);
	list.appendNode(4);
	list.appendNode(6);
	
	cout<<"Initial values:\n";
	list.displayList();
	cout<< endl;
	
	list.insertNode(5);
	
	cout<<"After inserting 5:\n";
	list.displayList();
	cout<< endl;
	
	list.deleteNode(6);
	
	cout<<"After deleting 6:\n";
	list.displayList();
	cout<< endl;
}
