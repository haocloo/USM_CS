#include <iostream>

class Health {
public:
    // Default constructor
    Health() : passportNum(0), ptr(nullptr), size(0) {}

    // Parameterized constructor
    Health(int num, int s) : passportNum(num), size(s) {
        ptr = new float[size];
    }

    // Copy constructor
    Health(const Health& other) {
        passportNum = other.passportNum;
        size = other.size;
        ptr = new float[size];
        for (int i = 0; i < size; i++) {
            ptr[i] = other.ptr[i];
        }
    }

    // Assignment operator overload
    Health& operator=(const Health& other) {
        if (this != &other) {
            passportNum = other.passportNum;
            size = other.size;
            delete[] ptr;
            ptr = new float[size];
            for (int i = 0; i < size; i++) {
                ptr[i] = other.ptr[i];
            }
        }
        return *this;
    }

    // Destructor
    ~Health() {
        delete[] ptr;
    }

    // Setters
    void setPassportNum(int num) {
        passportNum = num;
    }

    void setTemperature(float temp, int index) {
        if (index >= 0 && index < size) {
            ptr[index] = temp;
        } else {
            std::cout << "Invalid index" << std::endl;
        }
    }

    void setAge(float age, int index) {
        if (index >= 0 && index < size) {
            ptr[index + size] = age;
        } else {
            std::cout << "Invalid index" << std::endl;
        }
    }

    // Getters
    int getPassportNum() const {
        return passportNum;
    }

    float getTemperature(int index) const {
        if (index >= 0 && index < size) {
            return ptr[index];
        } else {
            std::cout << "Invalid index" << std::endl;
            return -1;
        }
    }

    float getAge(int index) const {
        if (index >= 0 && index < size) {
            return ptr[index + size];
        } else {
            std::cout << "Invalid index" << std::endl;
            return -1;
        }
    }

private:
    int passportNum;
    float* ptr;
    int size;
};

int main() {
    // Create a Health object with two elements in the dynamic array
    Health h1(1234);
    h1.setTemperature(0, 98.6);
    h1.setAge(0, 30);
    h1.setTemperature(1, 99.2);
    h1.setAge(1, 45);

    // Test the get methods
    std::cout << "Passport number: " << h1.getPassportNum() << std::endl;
    std::cout << "Temperature for element 0: " << h1.getTemperature(0) << std::endl;
    std::cout << "Age for element 1: " << h1.getAge(1) << std::endl;

    // Test the copy constructor
    Health h2(h1);
    std::cout << "Passport number for h2: " << h2.getPassportNum() << std::endl;
    std::cout << "Temperature for element 0 in h2: " << h2.getTemperature(0) << std::endl;

    // Test the assignment operator
    Health h3(5678);
    h3 = h1;
    std::cout << "Passport number for h3: " << h3.getPassportNum() << std::endl;
    std::cout << "Age for element 1 in h3: " << h3.getAge(1) << std::endl;

    return 0;
}


