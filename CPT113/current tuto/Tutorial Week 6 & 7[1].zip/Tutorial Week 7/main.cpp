#include <iostream>
#include "IntList.h"
using namespace std;

int main(){
	IntList list;
	list.appendNode(2);
	list.appendNode(4);
	list.appendNode(6);
	
	cout<<"Initial list:\n";
	list.displayNode();
	cout<< endl;
	
	list.insertNode(5);
	list.insertNode(0);
	list.insertNode(9);
	
	cout<<"Inserting 5, 0, 9:\n";
	list.displayNode();
	cout<< endl;
	
	list.deleteNode(-5);
	list.deleteNode(0);
	list.deleteNode(9);
	list.deleteNode(4);
	
	cout<<"Deleting -5, 0, 9, 4:\n";
	list.displayNode();
	cout<< endl;
	
	cout<<"Inserting 10 at pos 2:\n";
	list.insertSpecific(10,2);
	list.displayNode();
	cout<< endl;
	
	cout<<"Inserting 11 at pos 0:\n";
	list.insertSpecific(11,0);
	list.displayNode();
	cout<< endl;
}
