#include <iostream>
#include "Intlist.h"
using namespace std;

void IntList::appendNode(int num)
{
	ListNode *newNode, *nodePtr = nullptr;
	
	newNode = new ListNode;
	newNode-> value= num;	//neeNode is a pointer so need to use arrow
	newNode->next= nullptr; //The next one is nothing
	
	if(!head)	//if head is nullptr
		head = newNode;
	else		//if head has something
	{
		nodePtr = head;
		
		//Reach to last node
		while(nodePtr->next)	//while next of nodePtr has something, notePtr is next of nodePtr
			nodePtr = nodePtr->next;
		
		nodePtr->next= newNode;	//Insert new node as the last node
	}
}

void IntList::displayNode()
{
	ListNode *nodePtr= nullptr;
	nodePtr= head;				//for the nodePtr to be in front of list
	
	while (nodePtr)				//display all the value in the list
	{
		cout<< nodePtr -> value<< " ";
		nodePtr = nodePtr->next;
	}
}

void IntList::deleteNode(int num)
{
	ListNode *nodePtr, *previousNode = nullptr;
	
	if(!head)				//Head is empty
		return;
	if(head ->value == num)	//First node is the one to be deleted
	{
		nodePtr= head->next;
		delete head;
		head= nodePtr;
	}
	else
	{
		nodePtr = head;
		
		while(nodePtr != nullptr && nodePtr->value != num)	//not the last one and not equal to expected value
		{				//1. let say num is 5 and 5 is found is the list,previousNode = 5-1, nodePtr = 5
			previousNode= nodePtr;
			nodePtr= nodePtr->next;
		}
		
		if(nodePtr)		//nodePtr not at the end of List/not the nullptr (found element)
		{				//2. previousNode is assigned to next node of 5 and the 5 is deleted
			previousNode->next = nodePtr->next;	//previousNode = 5-1 related to next of nodePtr to form a line
			delete nodePtr;
		}
	}
}

void IntList::insertSpecific(int value, int pos)
{
	ListNode *newNode = new ListNode;
	newNode->value= value;
	newNode->next= nullptr;
	
	if(head == nullptr){
		head= newNode;
		return;
	}
	
	if( pos == 0)
	{
		newNode->next= head;
		head= newNode;
		return;
	}
	
	ListNode *nodePtr = head;
	int numberToSkip = 1;		//position here means array position
	
	while(numberToSkip <= pos)
	{
		if(nodePtr->next == nullptr || numberToSkip == pos)
		{
			ListNode *nextNode = nodePtr->next;
			nodePtr->next = newNode;
			newNode->next = nextNode;
			return;
		}
		
		nodePtr = nodePtr->next;
		numberToSkip++;
	}
}

void IntList::insertNode(int num)
{
	ListNode *newNode, *nodePtr, *previousNode = nullptr;
	
	newNode = new ListNode;
	newNode->value = num;
	
	if(!head)		//if head is empty
	{
		head = newNode;
		newNode->next = nullptr;
	}
	else			//if head is something
	{
		nodePtr = head;
		previousNode = nullptr;
		
		
		while (nodePtr != nullptr && nodePtr->value < num)	//Skip element until found node value is larger than num or until the end
		{
			previousNode = nodePtr;
			nodePtr = nodePtr-> next;
		}
		
		if(previousNode == nullptr)	//num < nodePtr for first value
		{
			head= newNode;
			newNode->next = nodePtr;
		}
		else
		{
			previousNode->next = newNode;
			newNode->next = nodePtr;
		}
	}
}

IntList::~IntList()
{
	ListNode *nodePtr, *nextNode = nullptr;
	
	nodePtr = head;
	
	while(nodePtr != nullptr)		//delete until the node is empty
	{
		nextNode = nodePtr->next;
		delete nodePtr;
		nodePtr = nextNode;
	}
}
